import os
import pickle
import numpy as np
import torch
import time

from PIL import Image
from tqdm import tqdm


def unpickle(file):
    with open(file, 'rb') as fo:
        dict = pickle.load(fo, encoding='bytes')
    return dict


def load_train_data(file_path, normalize=True):
    x_train, y_train = [], []
    for i in range(5):
        file_name = os.path.join(file_path, 'data_batch_' + str(i+1))
        dict = unpickle(file_name)

        for j in range(len(dict[b'data'])):
            x_train.append(dict[b'data'][j])
            y_train.append(dict[b'labels'][j])

    x_train = np.array(x_train).astype('float32')
    y_train = np.array(y_train)

    if normalize:
        x_train /= 255

    return x_train, y_train


def load_test_data(file_path, normalize=True):
    x_test, y_test = [], []

    file_name = os.path.join(file_path, 'test_batch')
    dict = unpickle(file_name)
    for j in range(len(dict[b'data'])):
        x_test.append(dict[b'data'][j])
        y_test.append(dict[b'labels'][j])

    x_test = np.array(x_test).astype('float32')
    y_test = np.array(y_test)

    if normalize:
        x_test /= 255

    return x_test, y_test


class Cifar10Dataset(torch.utils.data.Dataset):
    def __init__(self, file_path, train, transform=None, target_transform=None):
        self.file_path = file_path
        self.train = train
        self.transform = transform
        self.target_transform = target_transform
        self.image, self.label = [], []

        if train:
            self.load_train_data()
        else:
            self.load_test_data()

    def load_train_data(self):
        for i in range(5):
            file_name = os.path.join(self.file_path, 'data_batch_' + str(i + 1))
            dict = unpickle(file_name)

            for j in range(len(dict[b'data'])):
                self.image.append(dict[b'data'][j])
                self.label.append(dict[b'labels'][j])

        self.image = np.vstack(self.image).reshape(-1, 3, 32, 32)
        self.image = self.image.transpose((0, 2, 3, 1))

        self.label = np.array(self.label, dtype="int64")

    def load_test_data(self):
        file_name = os.path.join(self.file_path, 'test_batch')
        dict = unpickle(file_name)
        for j in range(len(dict[b'data'])):
            self.image.append(dict[b'data'][j])
            self.label.append(dict[b'labels'][j])

        self.image = np.vstack(self.image).reshape(-1, 3, 32, 32)
        self.image = self.image.transpose((0, 2, 3, 1))

        self.label = np.array(self.label, dtype="int64")

    def __len__(self):
        return len(self.label)

    def __getitem__(self, item):
        image, label = self.image[item], self.label[item]
        image = Image.fromarray(image)

        if self.transform:
            image = self.transform(image)
        if self.target_transform:
            label = self.target_transform(label)

        return image, label


def train_model(net, train_iter, test_iter, optimizer, device, num_epochs):
    net = net.to(device)
    print("training on", device)
    loss = torch.nn.CrossEntropyLoss()

    for epoch in range(num_epochs):
        train_l_sum, train_acc_sum, n, batch_count, start = 0.0, 0.0, 0, 0, time.time()

        with tqdm(total=len(train_iter), desc="Epoch %d" % epoch) as pbar:
            for X, y in train_iter:
                X = X.to(device)
                y = y.to(device)
                y_hat = net(X)

                l = loss(y_hat, y)

                optimizer.zero_grad()
                l.backward()
                optimizer.step()

                train_l_sum += l.cpu().item()
                train_acc_sum += (y_hat.argmax(dim=1) == y).sum().cpu().item()
                n += y.shape[0]
                batch_count += 1

                pbar.set_postfix({
                    'epoch': '%d' % (epoch + 1),
                    'train loss': '%.4f' % (train_l_sum / batch_count),
                    'train acc': '%.3f' % (train_acc_sum / n)
                })
                pbar.update(1)

        test_acc = evaluate_accuracy(test_iter, net)
        end = time.time()

        print('epoch %d, loss %.4f, train acc %.3f, test acc %.3f, time %.1f sec'
              % (epoch + 1, train_l_sum / batch_count, train_acc_sum / n, test_acc, time.time() - start))


def evaluate_accuracy(data_iter, net, device=None):
    if device is None and isinstance(net, torch.nn.Module):
        device = list(net.parameters())[0].device

    acc_sum, n = 0.0, 0
    with torch.no_grad():
        for X, y in data_iter:
            if isinstance(net, torch.nn.Module):
                net.eval()
                acc_sum += (net(X.to(device)).argmax(dim=1) == y.to(device)).float().sum().cpu().item()
                net.train()

            else:
                if 'is_training' in net.__code__.co_varnames:
                    acc_sum += (net(X, is_training=False).argmax(dim=1) == y).float().sum().item()
                else:
                    acc_sum += (net(X).argmax(dim=1) == y).float().sum().item()

            n += y.shape[0]
    return acc_sum / n