import os
import torch

from torch import nn, optim
from utils import Cifar10Dataset, train_model
from torchvision.transforms import Compose, ToTensor, Resize, Normalize

device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')


class LeNet(nn.Module):
    def __init__(self):
        super(LeNet, self).__init__()
        self.conv = nn.Sequential(
            nn.Conv2d(3, 6, 5),
            nn.Sigmoid(),
            nn.MaxPool2d(2, 2),
            nn.Conv2d(6, 16, 5),
            nn.Sigmoid(),
            nn.MaxPool2d(2, 2)
        )

        self.fc = nn.Sequential(
            nn.Linear(16*5*5, 120),
            nn.Sigmoid(),
            nn.Linear(120, 84),
            nn.Sigmoid(),
            nn.Linear(84, 10)
        )

    def forward(self, img):
        feature = self.conv(img)
        output = self.fc(feature.view(img.shape[0], -1))
        return output


net = LeNet()
print(net)


# batch_size = 256
#
# file_path = 'cifar-10'
# x_train, y_train = load_train_data(file_path)
# x_test, y_test = load_test_data(file_path)
#
# x_train = np.vstack(x_train).reshape(-1, 3, 32, 32)
# x_test = np.vstack(x_test).reshape(-1, 3, 32, 32)
#
# x_train, x_dev, y_train, y_dev = train_test_split(x_train, y_train, test_size=0.2)
#
# x_train = torch.tensor(x_train, dtype=torch.float32)
# x_dev = torch.tensor(x_dev, dtype=torch.float32)
# x_test = torch.tensor(x_test, dtype=torch.float32)
# y_train = torch.tensor(y_train, dtype=torch.int64)
# y_dev = torch.tensor(y_dev, dtype=torch.int64)
# y_test = torch.tensor(y_test, dtype=torch.int64)
#
# print(x_train.shape, y_train.shape)
# print(x_dev.shape, y_dev.shape)
# print(x_test.shape, y_test.shape)
#
# train_dataset = torch.utils.data.TensorDataset(x_train, y_train)
# dev_dataset = torch.utils.data.TensorDataset(x_dev, y_dev)
# test_dataset = torch.utils.data.TensorDataset(x_test, y_test)
#
# train_iter = torch.utils.data.DataLoader(train_dataset, batch_size, shuffle=True)
# dev_iter = torch.utils.data.DataLoader(dev_dataset, batch_size, shuffle=False)
# test_iter = torch.utils.data.DataLoader(test_dataset, batch_size, shuffle=False)
#
#
# def evaluate_accuracy(data_iter, net, device=None):
#     if device is None and isinstance(net, torch.nn.Module):
#         device = list(net.parameters())[0].device
#
#     acc_sum, n = 0.0, 0
#     with torch.no_grad():
#         for X, y in data_iter:
#             if isinstance(net, torch.nn.Module):
#                 net.eval()
#                 acc_sum += (net(X.to(device)).argmax(dim=1) == y.to(device)).float().sum().cpu().item()
#                 net.train()
#
#             else:
#                 if 'is_training' in net.__code__.co_varnames:
#                     acc_sum += (net(X, is_training=False).argmax(dim=1) == y).float().sum().item()
#                 else:
#                     acc_sum += (net(X).argmax(dim=1) == y).float().sum().item()
#
#             n += y.shape[0]
#     return acc_sum / n
#
#
# def train_model(net, train_iter, test_iter, optimizer, device, num_epochs):
#     net = net.to(device)
#     print("training on", device)
#     loss = torch.nn.CrossEntropyLoss()
#     for epoch in range(num_epochs):
#         train_l_sum, train_acc_sum, n, batch_count, start = 0.0, 0.0, 0, 0, time.time()
#         for X, y in train_iter:
#             X = X.to(device)
#             y = y.to(device)
#             y_hat = net(X)
#
#             l = loss(y_hat, y)
#
#             optimizer.zero_grad()
#             l.backward()
#             optimizer.step()
#
#             train_l_sum += l.cpu().item()
#             train_acc_sum += (y_hat.argmax(dim=1) == y).sum().cpu().item()
#             n += y.shape[0]
#             batch_count += 1
#
#         test_acc = evaluate_accuracy(test_iter, net)
#         print('epoch %d, loss %.4f, train acc %.3f, test acc %.3f, time %.1f sec'
#               % (epoch + 1, train_l_sum / batch_count, train_acc_sum / n, test_acc, time.time() - start))
#
#
# lr, num_epochs = 0.003, 50
# optimizer = torch.optim.Adam(net.parameters(), lr=lr)
# train_model(net, train_iter, test_iter, optimizer, device, num_epochs)

batch_size = 128

file_path = os.path.join('cifar-10')

_transform = Compose([

    ToTensor(),
    Normalize((0.485, 0.456, 0.406), (0.229, 0.224, 0.225)),
])

train_dataset = Cifar10Dataset(file_path, train=True, transform=_transform)
test_dataset = Cifar10Dataset(file_path, train=False, transform=_transform)


batch_size = 128
train_iter = torch.utils.data.DataLoader(train_dataset, batch_size, shuffle=True)
test_iter = torch.utils.data.DataLoader(test_dataset, batch_size, shuffle=False)


lr, num_epochs = 0.001, 5
optimizer = torch.optim.Adam(net.parameters(), lr=lr)
device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

train_model(net, train_iter, test_iter, optimizer, device, num_epochs)