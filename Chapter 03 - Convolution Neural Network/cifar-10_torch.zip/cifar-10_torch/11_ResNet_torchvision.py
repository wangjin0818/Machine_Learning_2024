import os
import torchvision
import torch
from torch import nn, optim
from utils import Cifar10Dataset, train_model
from torchvision.transforms import Normalize, Compose, ToTensor, Resize

resnet50 = torchvision.models.resnet50(pretrained=True)
print(resnet50)
resnet50.add_module("Classifier", nn.Linear(1000, 10))
print(resnet50)

file_path = os.path.join('cifar-10')

_transform = Compose([
    Resize(224),
    ToTensor(),
    Normalize((0.485, 0.456, 0.406), (0.229, 0.224, 0.225)),
])

train_dataset = Cifar10Dataset(file_path, train=True, transform=_transform)
test_dataset = Cifar10Dataset(file_path, train=False, transform=_transform)


batch_size = 64
train_iter = torch.utils.data.DataLoader(train_dataset, batch_size, shuffle=True)
test_iter = torch.utils.data.DataLoader(test_dataset, batch_size, shuffle=False)


lr, num_epochs = 0.001, 5
optimizer = torch.optim.Adam(resnet50.parameters(), lr=lr)
device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')

train_model(resnet50, train_iter, test_iter, optimizer, device, num_epochs)
