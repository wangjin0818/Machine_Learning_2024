# from utils import load_train_data
#
# file_path = 'cifar-10'
# x_train, y_train = load_train_data(file_path)
#
# print(x_train.shape)
#
#
# import torchvision
# from torchvision import transforms
# transform = transforms.Compose([transforms.ToTensor(),
#                                  transforms.Normalize((0.5, 0.5, 0.5), (0.5, 0.5, 0.5))])
#
# trainset = torchvision.datasets.CIFAR10(root='./data', train=True,
#                                         download=True, transform=transform)

import os
import pickle
import numpy as np
import torch
from PIL import Image


def unpickle(file):
    with open(file, 'rb') as fo:
        dict = pickle.load(fo, encoding='bytes')
    return dict


class Cifar10Dataset(torch.utils.data.Dataset):
    def __init__(self, file_path, train, transform=None, target_transform=None):
        self.file_path = file_path
        self.train = train
        self.transform = transform
        self.target_transform = target_transform
        self.image, self.label = [], []

        if train:
            self.load_train_data()
        else:
            self.load_test_data()

    def load_train_data(self):
        for i in range(5):
            file_name = os.path.join(self.file_path, 'data_batch_' + str(i + 1))
            dict = unpickle(file_name)

            for j in range(len(dict[b'data'])):
                self.image.append(dict[b'data'][j])
                self.label.append(dict[b'labels'][j])

        self.image = np.vstack(self.image).reshape(-1, 3, 32, 32)
        self.image = self.image.transpose((0, 2, 3, 1))

        self.label = np.array(self.label)

    def load_test_data(self):
        file_name = os.path.join(self.file_path, 'test_batch')
        dict = unpickle(file_name)
        for j in range(len(dict[b'data'])):
            self.image.append(dict[b'data'][j])
            self.image.append(dict[b'labels'][j])

        self.image = np.vstack(self.image).reshape(-1, 3, 32, 32)
        self.image = self.image.transpose((0, 2, 3, 1))

        self.label = np.array(self.label)

    def __len__(self):
        return len(self.label)

    def __getitem__(self, item):
        image, label = self.image[item], self.label[item]

        print(image.shape)
        image = Image.fromarray(image)

        if self.transform:
            image = self.transform(image)
        if self.target_transform:
            label = self.target_transform(label)

        return image, label


from torchvision.transforms import ToTensor, Normalize, Compose

_transform = Compose([
    ToTensor(),
    Normalize((0.485, 0.456, 0.406), (0.229, 0.224, 0.225)),
])

file_path = os.path.join('cifar-10')
train_dataset = Cifar10Dataset(file_path, train=True, transform=_transform)

train_iter = torch.utils.data.DataLoader(train_dataset, batch_size=256, shuffle=True)

for x_train, y_train in train_iter:
    print(x_train.shape)
    print(y_train.shape)

